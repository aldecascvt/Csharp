﻿using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace Grades.WPF
{
    public partial class StudentPhoto : UserControl
    {
        #region Constructor
        public StudentPhoto()
        {
            InitializeComponent();
        }
        #endregion

        #region Storyboard
        

        #endregion
    }
}
